<div id="share-buttons">
    <!-- Facebook -->
    <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" title="পোস্টটি ফেসবুকে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/facebook.png" height="30" width="30" alt="Facebook" />
    </a>
        
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=<?php the_permalink(); ?>&amp;text=<?php the_title(); ?>" title="পোস্টটি টুইটারে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/twitter.png" height="30" width="30" alt="Twitter" />
    </a>

    <!-- Google+ -->
    <a href="https://plus.google.com/share?url=<?php the_title(); ?> | ব্লগার বিডি ২৪%20<?php the_permalink(); ?>" title="পোস্টটি গুগোল প্লাসে শেয়ার করুন" target="_blank">
        <img src="<?php bloginfo('template_url'); ?>/share/google.png" height="30" width="30" alt="Google" />
    </a>


    <!-- Email -->
    <a title="পোস্টটি ইমেইল করুন"
href="mailto:?subject=<?php the_title(); ?>&amp;body=<?php the_title(); ?>%20<?php the_permalink(); ?>">
        <img src="<?php bloginfo('template_url'); ?>/share/email.png" height="30" width="30" alt="Email" />
    </a>
    
</div>